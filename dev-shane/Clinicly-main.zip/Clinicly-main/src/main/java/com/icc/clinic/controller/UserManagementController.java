package com.icc.clinic.controller;

import com.icc.clinic.model.Role;
import com.icc.clinic.model.User;
import com.icc.clinic.service.RBACService;
import com.icc.clinic.service.UserService;
import com.icc.clinic.service.PasswordService;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.StringConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class UserManagementController {

    @FXML private TableView<User> usersTable;
    @FXML private TableColumn<User, String> usernameColumn;
    @FXML private TableColumn<User, String> firstNameColumn;
    @FXML private TableColumn<User, String> lastNameColumn;
    @FXML private TableColumn<User, String> emailColumn;
    @FXML private TableColumn<User, String> roleColumn;
    @FXML private TableColumn<User, Boolean> activeColumn;

    @FXML private TextField usernameField;
    @FXML private TextField firstNameField;
    @FXML private TextField lastNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private ComboBox<Role> roleComboBox;
    @FXML private CheckBox activeCheckBox;

    @FXML private Button addUserButton;
    @FXML private Button editUserButton;
    @FXML private Button deleteUserButton;
    @FXML private Button refreshButton;
    @FXML private Button saveUserButton;
    
    @FXML private Label roleDescriptionLabel;
    
    private boolean isEditMode = false;

    @Autowired
    private UserService userService;

    @Autowired
    private RBACService rbacService;

    @Autowired
    private PasswordService passwordService;

    private User selectedUser;

    @FXML
    public void initialize() {
        setupTable();
        setupComboBoxes();
        loadUsers();
        loadRoles();
        setupFormFields();
        updateButtonStates();
    }

    private void setupTable() {
        usernameColumn.setCellValueFactory(new PropertyValueFactory<>("username"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        roleColumn.setCellValueFactory(cellData -> {
            User user = cellData.getValue();
            return new javafx.beans.property.SimpleStringProperty(
                user.getRole() != null ? user.getRole().getName() : "No Role"
            );
        });
        activeColumn.setCellValueFactory(new PropertyValueFactory<>("active"));

        // Add selection listener
        usersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            selectedUser = newSelection;
            if (newSelection != null) {
                populateForm(newSelection);
            } else {
                clearForm();
            }
        });
        
        // Add role selection listener for real-time feedback
        roleComboBox.valueProperty().addListener((obs, oldRole, newRole) -> {
            updateRoleDescription(newRole);
            // Show temporary password indicator when role is selected
            if (newRole != null && !isEditMode) {
                passwordField.setText("temporary/default");
                passwordField.setStyle("-fx-text-fill: #666; -fx-font-style: italic;");
                updatePasswordTooltip(newRole.getName());
            }
        });
    }

    private void setupFormFields() {
        // Initially disable all form fields
        setFormFieldsEnabled(false);
    }
    
    private void setFormFieldsEnabled(boolean enabled) {
        usernameField.setDisable(!enabled);
        firstNameField.setDisable(!enabled);
        lastNameField.setDisable(!enabled);
        emailField.setDisable(!enabled);
        // Password field is always read-only for new users, editable only when editing existing users
        if (isEditMode) {
            passwordField.setDisable(!enabled);
        } else {
            passwordField.setDisable(true); // Always disabled for new users
        }
        roleComboBox.setDisable(!enabled);
        activeCheckBox.setDisable(!enabled);
    }
    
    private void updateButtonStates() {
        if (isEditMode) {
            // Edit mode: Show Save button, hide Edit button
            editUserButton.setVisible(false);
            saveUserButton.setVisible(true);
            addUserButton.setDisable(true);
            deleteUserButton.setDisable(true);
        } else {
            // Normal mode: Show Edit button, hide Save button
            editUserButton.setVisible(true);
            saveUserButton.setVisible(false);
            addUserButton.setDisable(false);
            deleteUserButton.setDisable(selectedUser == null);
        }
    }

    private void setupComboBoxes() {
        roleComboBox.setConverter(new StringConverter<Role>() {
            @Override
            public String toString(Role role) {
                if (role == null) return "";
                return role.getName() + " - " + role.getDescription();
            }

            @Override
            public Role fromString(String string) {
                return null;
            }
        });
        
        // Add cell factory for better display
        roleComboBox.setCellFactory(listView -> new ListCell<Role>() {
            @Override
            protected void updateItem(Role role, boolean empty) {
                super.updateItem(role, empty);
                if (empty || role == null) {
                    setText(null);
                    setGraphic(null);
                } else {
                    setText(role.getName() + " - " + role.getDescription());
                    // Add some styling based on role
                    if ("IT".equals(role.getName())) {
                        setStyle("-fx-background-color: #e3f2fd; -fx-text-fill: #1976d2;");
                    } else if ("NURSE".equals(role.getName())) {
                        setStyle("-fx-background-color: #f3e5f5; -fx-text-fill: #7b1fa2;");
                    } else {
                        setStyle("");
                    }
                }
            }
        });
    }

    private void loadUsers() {
        List<User> users = userService.getAllUsers();
        usersTable.getItems().setAll(users);
    }

    private void loadRoles() {
        List<Role> roles = rbacService.getAllRoles();
        roleComboBox.getItems().setAll(roles);
    }

    private void populateForm(User user) {
        usernameField.setText(user.getUsername());
        firstNameField.setText(user.getFirstName());
        lastNameField.setText(user.getLastName());
        emailField.setText(user.getEmail());
        passwordField.clear(); // Don't populate password for security
        roleComboBox.setValue(user.getRole());
        activeCheckBox.setSelected(user.getActive());
        
        // Update role description when user is selected
        updateRoleDescription(user.getRole());
        
        // Update button states
        updateButtonStates();
    }
    
    private void updateRoleDescription(Role role) {
        if (role != null && roleDescriptionLabel != null) {
            String description = getDetailedRoleDescription(role);
            roleDescriptionLabel.setText(description);
            
            // Update styling based on role
            if ("IT".equals(role.getName())) {
                roleDescriptionLabel.setStyle("-fx-text-fill: #1976d2; -fx-font-weight: bold;");
            } else if ("NURSE".equals(role.getName())) {
                roleDescriptionLabel.setStyle("-fx-text-fill: #7b1fa2; -fx-font-weight: bold;");
            } else {
                roleDescriptionLabel.setStyle("-fx-text-fill: #333;");
            }
        }
    }
    
    private String getDetailedRoleDescription(Role role) {
        if (role == null) return "Select a role to see details";
        
        switch (role.getName()) {
            case "IT":
                return "IT Administrator - Full system access including user management, system configuration, and all clinical operations";
            case "NURSE":
                return "Nurse - Clinical operations including patient management, appointment scheduling, and data import/export";
            default:
                return role.getDescription();
        }
    }
    
    private void updatePasswordTooltip(String roleName) {
        String defaultPassword = passwordService.getDefaultPasswordForRole(roleName);
        String tooltipText = String.format(
            "Default password: %s\n\n" +
            "⚠️ User must change password on first login\n" +
            "Password requirements:\n" +
            "• At least 8 characters\n" +
            "• Uppercase and lowercase letters\n" +
            "• Numbers and special characters (@$!%%*?&)\n" +
            "• Cannot be the default password",
            defaultPassword
        );
        
        Tooltip tooltip = new Tooltip(tooltipText);
        tooltip.setStyle("-fx-font-size: 11px; -fx-max-width: 300px;");
        passwordField.setTooltip(tooltip);
    }

    private void clearForm() {
        usernameField.clear();
        firstNameField.clear();
        lastNameField.clear();
        emailField.clear();
        passwordField.clear();
        passwordField.setStyle(""); // Reset styling
        passwordField.setTooltip(null); // Clear tooltip
        roleComboBox.setValue(null);
        activeCheckBox.setSelected(true);
        selectedUser = null;
        isEditMode = false;
        
        // Disable form fields and update button states
        setFormFieldsEnabled(false);
        updateButtonStates();
        
        // Clear role description
        if (roleDescriptionLabel != null) {
            roleDescriptionLabel.setText("Select a role to see details");
            roleDescriptionLabel.setStyle("-fx-text-fill: #333;");
        }
    }

    @FXML
    private void handleAddUser() {
        // Prepare form for creating a new user
        clearForm();
        selectedUser = null;

        // Enter save mode so the Save button is visible
        isEditMode = true;
        setFormFieldsEnabled(true);

        // Password for new users is auto-assigned; keep field disabled and show placeholder
        passwordField.setDisable(true);
        passwordField.setText("temporary/default");
        passwordField.setStyle("-fx-text-fill: #666; -fx-font-style: italic;");
        updatePasswordTooltip("NURSE");

        updateButtonStates();

        // Focus on username field
        usernameField.requestFocus();
    }

    @FXML
    private void handleEditUser() {
        if (selectedUser == null) {
            showErrorMessage("Please select a user to edit.");
            return;
        }

        // Enable edit mode
        isEditMode = true;
        setFormFieldsEnabled(true);
        updateButtonStates();
        
        // Focus on first name field
        firstNameField.requestFocus();
    }

    @FXML
    private void handleSaveUser() {
        if (validateForm()) {
            try {
                if (isEditMode && selectedUser != null) {
                    // Editing existing user
                    selectedUser.setUsername(usernameField.getText());
                    selectedUser.setFirstName(firstNameField.getText());
                    selectedUser.setLastName(lastNameField.getText());
                    selectedUser.setEmail(emailField.getText());
                    if (!passwordField.getText().isEmpty()) {
                        selectedUser.setPassword(passwordField.getText());
                    }
                    selectedUser.setRole(roleComboBox.getValue());
                    selectedUser.setActive(activeCheckBox.isSelected());

                    userService.saveUser(selectedUser);
                    loadUsers();
                    showSuccessMessage("User updated successfully!");
                } else {
                    // Adding new user
                    User user = new User();
                    user.setUsername(usernameField.getText());
                    user.setFirstName(firstNameField.getText());
                    user.setLastName(lastNameField.getText());
                    user.setEmail(emailField.getText());
                    // Use actual default password for the role
                    String actualPassword = passwordService.getDefaultPasswordForRole(roleComboBox.getValue().getName());
                    user.setPassword(actualPassword);
                    user.setRole(roleComboBox.getValue());
                    user.setActive(activeCheckBox.isSelected());
                    
                    // Set default password flag
                    user.setIsDefaultPassword(true);
                    if (user.getIsDefaultPassword()) {
                        user.setPasswordChangedAt(null);
                    } else {
                        user.setPasswordChangedAt(java.time.LocalDateTime.now());
                    }

                    userService.saveUser(user);
                    loadUsers();
                    showSuccessMessage("User added successfully!");
                }
                
                // Exit edit mode
                isEditMode = false;
                setFormFieldsEnabled(false);
                updateButtonStates();
                
            } catch (Exception e) {
                showErrorMessage("Error saving user: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleDeleteUser() {
        if (selectedUser == null) {
            showErrorMessage("Please select a user to delete.");
            return;
        }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm Delete");
        alert.setHeaderText("Delete User");
        alert.setContentText("Are you sure you want to delete user: " + selectedUser.getUsername() + "?");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                try {
                    userService.deleteUser(selectedUser.getId());
                    loadUsers();
                    clearForm();
                    showSuccessMessage("User deleted successfully!");
                } catch (Exception e) {
                    showErrorMessage("Error deleting user: " + e.getMessage());
                }
            }
        });
    }

    @FXML
    private void handleRefresh() {
        loadUsers();
        usersTable.refresh();
        loadRoles();
    }

    private boolean validateForm() {
        if (usernameField.getText().trim().isEmpty()) {
            showErrorMessage("Username is required.");
            return false;
        }
        if (firstNameField.getText().trim().isEmpty()) {
            showErrorMessage("First name is required.");
            return false;
        }
        if (lastNameField.getText().trim().isEmpty()) {
            showErrorMessage("Last name is required.");
            return false;
        }
        if (emailField.getText().trim().isEmpty()) {
            showErrorMessage("Email is required.");
            return false;
        }
        if (roleComboBox.getValue() == null) {
            showErrorMessage("Role is required.");
            return false;
        }
        // Password validation is handled automatically for new users

        // Check for duplicate username
        if (selectedUser == null || !selectedUser.getUsername().equals(usernameField.getText())) {
            if (userService.userExists(usernameField.getText())) {
                showErrorMessage("Username already exists.");
                return false;
            }
        }

        // Check for duplicate email
        if (selectedUser == null || !selectedUser.getEmail().equals(emailField.getText())) {
            if (userService.emailExists(emailField.getText())) {
                showErrorMessage("Email already exists.");
                return false;
            }
        }

        return true;
    }

    private void showSuccessMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void showErrorMessage(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
